﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityLayer;

namespace DataAccessLayer
{
    public class RegistrationDAL
    {
        masterEntities db = new masterEntities();
        public bool InsertRegistration(RegistrationEntity re)
        {
            try
            {
                Registration rdb = new Registration();//contain the new of data to be inserted
                rdb.Name = re.Name;
                rdb.Address = re.Address;
                rdb.DOB = re.DOB;
                rdb.DOJ = re.DOJ;
                rdb.Nationality = re.Nationality;
                rdb.Qualification = re.Quali;
                rdb.Hobbies = re.Hobbies;
                rdb.SkillSets = re.Skills;
                rdb.Salary = re.Salary;

                db.Registrations.AddObject(rdb);//add to conceptual model
                int res = db.SaveChanges();//update the values in conceptual model to actual DB

                if (res > 0)
                    return true;


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
    }
}
