﻿select * from LoginInfo

insert into Logininfo values (11111,'hello')